package com.burgerclub.stafftracker.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.data.model.ShiftRecord

@Database(
    entities = [Employee::class, ShiftRecord::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun employeeDao(): EmployeeDao
    abstract fun shiftRecordDao(): ShiftRecordDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "burger_club_db"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
