package com.burgerclub.stafftracker.ui.main

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.burgerclub.stafftracker.R
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.databinding.ActivityMainBinding
import com.burgerclub.stafftracker.ui.admin.AdminActivity
import com.burgerclub.stafftracker.ui.camera.CameraActivity
import com.burgerclub.stafftracker.utils.DateUtils
import com.burgerclub.stafftracker.utils.NotificationHelper

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: EmployeeAdapter
    private val clockHandler = Handler(Looper.getMainLooper())
    private var pendingAction: String = ""

    private val cameraLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val photoPath = result.data?.getStringExtra("photo_path")
        val employee = viewModel.selectedEmployee ?: return@registerForActivityResult
        if (pendingAction == "check_in") {
            viewModel.checkIn(employee, photoPath) { res ->
                res.onSuccess {
                    Toast.makeText(this, "✅ ${employee.name}: смена начата", Toast.LENGTH_LONG).show()
                    adapter.notifyDataSetChanged()
                }.onFailure {
                    val msg = if (it.message == "already_checked_in")
                        getString(R.string.already_checked_in) else it.message ?: "Ошибка"
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }
            }
        } else if (pendingAction == "check_out") {
            viewModel.checkOut(employee, photoPath) { res ->
                res.onSuccess { rec ->
                    val hours = "%.1f".format(rec.billedHours)
                    val salary = "%.0f".format(rec.salary)
                    Toast.makeText(this,
                        "✅ ${employee.name}: смена закрыта\n${hours} ч | ${salary} руб",
                        Toast.LENGTH_LONG).show()
                }.onFailure {
                    val msg = if (it.message == "not_checked_in")
                        getString(R.string.not_checked_in) else it.message ?: "Ошибка"
                    Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private val clockRunnable = object : Runnable {
        override fun run() {
            binding.tvClock.text = DateUtils.currentTimeString()
            clockHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        NotificationHelper.createNotificationChannel(this)

        setupRecyclerView()
        setupButtons()
        startClock()

        viewModel.employees.observe(this) { list ->
            adapter.submitList(list)
            binding.tvNoEmployees.visibility =
                if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    private fun setupRecyclerView() {
        adapter = EmployeeAdapter { employee ->
            selectEmployee(employee)
        }
        binding.rvEmployees.adapter = adapter
        binding.rvEmployees.layoutManager =
            androidx.recyclerview.widget.GridLayoutManager(this, 3)
    }

    private fun setupButtons() {
        binding.btnCheckIn.setOnClickListener {
            val emp = viewModel.selectedEmployee
            if (emp == null) {
                Toast.makeText(this, getString(R.string.select_employee), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            showPinDialog(emp) { openCamera("check_in") }
        }

        binding.btnCheckOut.setOnClickListener {
            val emp = viewModel.selectedEmployee
            if (emp == null) {
                Toast.makeText(this, getString(R.string.select_employee), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            showPinDialog(emp) { openCamera("check_out") }
        }

        binding.btnAdmin.setOnClickListener {
            showAdminPasswordDialog()
        }
    }

    private fun selectEmployee(employee: Employee) {
        viewModel.selectedEmployee = employee
        adapter.setSelected(employee.id)
        binding.tvSelectedEmployee.text = "Выбран: ${employee.name}"
        binding.btnCheckIn.isEnabled = true
        binding.btnCheckOut.isEnabled = true
    }

    private fun showPinDialog(employee: Employee, onSuccess: () -> Unit) {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_pin, null)
        val etPin = view.findViewById<EditText>(R.id.etPin)

        AlertDialog.Builder(this)
            .setTitle("${employee.name} — введите PIN")
            .setView(view)
            .setPositiveButton("Подтвердить") { _, _ ->
                val entered = etPin.text.toString()
                if (entered == employee.pinCode) {
                    onSuccess()
                } else {
                    Toast.makeText(this, getString(R.string.wrong_pin), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun showAdminPasswordDialog() {
        val view = LayoutInflater.from(this).inflate(R.layout.dialog_pin, null)
        val etPin = view.findViewById<EditText>(R.id.etPin)
        etPin.hint = "Пароль администратора"

        AlertDialog.Builder(this)
            .setTitle(getString(R.string.admin_password))
            .setView(view)
            .setPositiveButton("Войти") { _, _ ->
                val pwd = etPin.text.toString()
                if (pwd == "admin1234") {
                    startActivity(Intent(this, AdminActivity::class.java))
                } else {
                    Toast.makeText(this, getString(R.string.wrong_admin_password), Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton(getString(R.string.cancel), null)
            .show()
    }

    private fun openCamera(action: String) {
        pendingAction = action
        val intent = Intent(this, CameraActivity::class.java)
        cameraLauncher.launch(intent)
    }

    private fun startClock() {
        clockHandler.post(clockRunnable)
    }

    override fun onDestroy() {
        super.onDestroy()
        clockHandler.removeCallbacks(clockRunnable)
    }
}
