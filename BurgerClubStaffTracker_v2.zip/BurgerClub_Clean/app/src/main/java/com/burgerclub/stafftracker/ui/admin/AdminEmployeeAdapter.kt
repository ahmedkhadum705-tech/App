package com.burgerclub.stafftracker.ui.admin

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.databinding.ItemEmployeeAdminBinding

class AdminEmployeeAdapter(
    private val onEdit: (Employee) -> Unit,
    private val onDelete: (Employee) -> Unit
) : ListAdapter<Employee, AdminEmployeeAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemEmployeeAdminBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(emp: Employee) {
            b.tvName.text = emp.name
            b.tvDetails.text = "Ставка: ${emp.hourlyRate.toInt()} руб/ч  |  Смена с ${emp.shiftStartTime}  |  PIN: ${"•".repeat(emp.pinCode.length)}"
            b.tvStatus.text = if (emp.isOnShift) "🟢 На смене" else "⚫ Не работает"
            b.btnEdit.setOnClickListener { onEdit(emp) }
            b.btnDelete.setOnClickListener { onDelete(emp) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemEmployeeAdminBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Employee>() {
            override fun areItemsTheSame(a: Employee, b: Employee) = a.id == b.id
            override fun areContentsTheSame(a: Employee, b: Employee) = a == b
        }
    }
}
