package com.burgerclub.stafftracker.ui.main

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.burgerclub.stafftracker.data.model.Employee
import com.burgerclub.stafftracker.databinding.ItemEmployeeCardBinding

class EmployeeAdapter(
    private val onClick: (Employee) -> Unit
) : ListAdapter<Employee, EmployeeAdapter.VH>(DIFF) {

    private var selectedId: Long = -1L

    fun setSelected(id: Long) {
        val old = currentList.indexOfFirst { it.id == selectedId }
        val new = currentList.indexOfFirst { it.id == id }
        selectedId = id
        if (old >= 0) notifyItemChanged(old)
        if (new >= 0) notifyItemChanged(new)
    }

    inner class VH(private val b: ItemEmployeeCardBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(emp: Employee) {
            b.tvName.text = emp.name
            b.tvRate.text = "${emp.hourlyRate.toInt()} руб/ч"
            b.tvShiftStart.text = "Смена: ${emp.shiftStartTime}"
            b.ivStatus.setImageResource(
                if (emp.isOnShift) android.R.drawable.presence_online
                else android.R.drawable.presence_offline
            )
            val isSelected = emp.id == selectedId
            b.root.strokeWidth = if (isSelected) 4 else 0
            b.root.setOnClickListener { onClick(emp) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemEmployeeCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Employee>() {
            override fun areItemsTheSame(a: Employee, b: Employee) = a.id == b.id
            override fun areContentsTheSame(a: Employee, b: Employee) = a == b
        }
    }
}
