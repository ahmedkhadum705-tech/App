package com.burgerclub.stafftracker.ui.rating

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.burgerclub.stafftracker.data.repository.StaffRepository
import com.burgerclub.stafftracker.databinding.ItemRatingBinding
import com.burgerclub.stafftracker.utils.SalaryCalculator

class RatingAdapter : ListAdapter<StaffRepository.EmployeeRating, RatingAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemRatingBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: StaffRepository.EmployeeRating, position: Int) {
            val medal = when (position) {
                0 -> "🥇"
                1 -> "🥈"
                2 -> "🥉"
                else -> "${position + 1}."
            }
            b.tvRank.text = medal
            b.tvName.text = item.employee.name
            b.tvHours.text = "Отработано: ${SalaryCalculator.formatHours(item.totalHours)}"
            b.tvLates.text = "Опозданий: ${item.lateCount}"
            b.tvScore.text = "Очки: ${String.format("%.1f", item.score)}"
            b.tvScore.setTextColor(
                if (item.score >= 0)
                    b.root.context.getColor(com.burgerclub.stafftracker.R.color.green_success)
                else
                    b.root.context.getColor(com.burgerclub.stafftracker.R.color.red_error)
            )
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val b = ItemRatingBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(b)
    }

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position), position)

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<StaffRepository.EmployeeRating>() {
            override fun areItemsTheSame(a: StaffRepository.EmployeeRating, b: StaffRepository.EmployeeRating) =
                a.employee.id == b.employee.id
            override fun areContentsTheSame(a: StaffRepository.EmployeeRating, b: StaffRepository.EmployeeRating) =
                a == b
        }
    }
}
