package com.burgerclub.stafftracker.data.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

@Entity(
    tableName = "shift_records",
    foreignKeys = [
        ForeignKey(
            entity = Employee::class,
            parentColumns = ["id"],
            childColumns = ["employeeId"],
            onDelete = ForeignKey.CASCADE
        )
    ]
)
data class ShiftRecord(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val employeeId: Long,
    val employeeName: String,
    val checkInTime: Long,        // timestamp millis
    val checkOutTime: Long? = null,
    val checkInPhotoPath: String? = null,
    val checkOutPhotoPath: String? = null,
    val isLate: Boolean = false,
    val lateMinutes: Int = 0,
    val billedHours: Double = 0.0,
    val salary: Double = 0.0
)
