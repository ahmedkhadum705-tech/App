package com.burgerclub.stafftracker

import android.app.Application
import com.burgerclub.stafftracker.utils.NotificationHelper

class BurgerClubApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationHelper.createNotificationChannel(this)
    }
}
